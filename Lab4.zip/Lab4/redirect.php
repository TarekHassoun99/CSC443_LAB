<?php

//  The first page redirects to a PHP page that takes the
// usernameand Password,
// checks if they are present in a database table “users”.
// 1)   Case where user does not existAdd the user to the database,
// and send the username and Password to the next PHP page via a
//  GET request.Note: Remember, to send variables via GET requests redirect
//  to the page and add the variables at the end of the URLusing the header function:
//  URL example: “user.php?username={$var1}&Password={$var2}”
//  2)  Case where user exists
//  Check if the  user  exists, and if they do redirect  them to the  page  they already created(in step 3),
// if the password matches the password in the database.

function connectServer($servername, $username, $password)
{
    $connection = new mysqli($servername, $username, $password);
    if ($connection->connect_error) {
        throw new Exception("Connection Error");
    } else {
        return $connection;
    }
}

function connectDb($servername, $username, $password, $dbname)
{
    $connection = new mysqli($servername, $username, $password, $dbname);
    if ($connection->connect_error) {
        throw new Exception("Connection Error");
    } else {
        return $connection;
    }
}

function selectQuery($connection, $query)
{
    $result = $connection->query($query);

    $multiArray = array();
    while ($row = $result->fetch_assoc()) {
        array_push($multiArray, $row);
    }
    return $multiArray;
}

function executeQuery($connection, $query)
{
    $result = $connection->query($query);
    return $result;
}

function userExists($connection, $tablename, $username)
{
    $result = selectQuery($connection, "select * from $tablename where username='$username'");
    return count($result) > 0;
}
function checkPasswordMatch($password, $ccpassword) //Consider deleting later
{
    return ($password == $ccpassword);
}
function addUser($connection, $tablename, $password, $ccpassword, $username) //Consider modifying to only add users.
{
    if (userExists($connection, $tablename, $username)) {
        return -1;
    }
    if (!checkPasswordMatch($password, $ccpassword)) {
        return -2;
    }
    $hashedPassword = md5($password);

    executeQuery($connection, "Insert into $tablename (username,password) values ('$username','$hashedPassword')");
    return 1;
}

function passwordMatches($connection, $tablename, $username, $password) //consider deleting
{
    $result = selectQuery($connection, "Select password from $tablename where username='$username'");
    return $result[0]["password"] == md5($password);

}

function signInUser($connection, $tablename, $username, $password)
{
    if (userExists($connection, $tablename, $username)) {
        if (passwordMatches($connection, $tablename, $username, $password)) { //consider if to delete this alternative possibility accordingly
            return 1;
        }
        return -1;
    }
    return -2;
}
function alert($msg)
{
    echo "<script type='text/javascript'>alert('$msg');</script>";
}

$connection = connectServer("localhost","root",file_get_contents("./pass.txt"));
$result= executeQuery($connection,"create database test_db_2");
/*$result= executeQuery($connection, "create table users(
id int(32) auto_increment primary key,
username varchar(255),
password varchar(255))");
*/

if($_SERVER["REQUEST_METHOD"]=="POST")
{

    
    $result= addUser($connection,"users",$_POST["txt_password"],$_POST["password"],$_POST["txt_username"]);
    if($result==-1)
    {
        alert("user Exists");
    }
    else if($result==-2)
    {
        alert("password dont match");
    }
    else if($result==1)
    {
        alert("added successfully");
    }
}

if($_SERVER["REQUEST_METHOD"]=="GET" && isset($_GET["txt_username"])) //I thought of deleting this seeing as the original request is to just create a POST action, but it seems to have too many things related to it.
{
    $result= signInUser($connection,"users",$_GET["txt_username"],$_GET["txt_password"]);

    if($result==-1)
    {
        alert("password is wrong");
    }
    else if($result==-2)
    {
        alert("user does not exist");
    }
    else if($result==1)
    {
        alert("signed in");
        header("Location:./signin.html");
    }

}
