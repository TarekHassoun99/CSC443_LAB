<?php

// This page takes the username of the user and writes itin the title of the
// page. The page should contain:
// a)A textarea with a label “introduction” where the user introduces themselves.
// b)A Button called add Image, that will add a “File” input field when clicked.
// c)Finally, asubmitbutton that will create a new html page using these elements.On button click,
//the information saved on the page will be  used to build an html page  for the user. The following things should occur:
//     1)For each user create a folder using the username.
//     2)First you will need to writethe HTML codefor the pagein a stringbefore adding it to an HTMLfile.
//     3)Write the <html><body>.... Tags in a script.
// 4)Inside body add headerwith the name of the user.
// 5)A subheaderIntroduction followed by the given information
// 6)A subheader Image with the chosen image (remember that you will need to save the given image in the user’s folder,
//save it as “img.jpg”. Make sure to correctly referencethe image in the HTML string)
//  7)Finally, when you are done writing the HTML code, save it in a “user.html” page in the user’s folder.
// 8)Open the HTML page you created.

session_start();
$username = "";
$intro = "";
$intro = $_POST['introduction'];
$addImage = "";
$addImage = $_POST['addImage'];

$username = $_SESSION['txt_username'];
if (file_exists($username)) {
    header("Location:$username/user.html");
} else {
    mkdir("$username");
}
$fp = fopen("$username/user.html", "w");

if (isset($_POST['Submit'])) {
    echo copy($_POST['addImage'], "$username/img.jpg");
    $content = "
    <html>
    <body>
        <h1>$username</h1>
        <br>
        <br>
        <p>$intro</p>
        <p><img src=$addImage></p>
    </body>
    </html>";
    fwrite($fp, $content);
    fclose($file);

    header("Location:$username/user.html");
}

?>

<html>
<head>
</head>
<body>
    <h1>

    <?php echo $_SESSION['username']; ?>

</h1>
Introduction:
<form method="POST">

<textarea name="introduction"></textarea>
<input type="file" name="addImage">

<button type="submit" name="Submit"/></button>

</form>
</body>

</html>
