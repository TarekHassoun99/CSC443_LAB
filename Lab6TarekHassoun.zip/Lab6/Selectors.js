// $("li");
// $("li").hide();
// $("li").show();
// $("li.test").hide();


function turnBlue() {
    if($("li").attr("style")===undefined){
    $("li").attr("style", "color: blue");}
    else
    $("li").removeAttr("style");
    }