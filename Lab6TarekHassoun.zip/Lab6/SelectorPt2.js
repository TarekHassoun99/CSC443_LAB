function colorChange() {
    let newColor=document.getElementById("input_color").value;
    $("strong").text(newColor);
}