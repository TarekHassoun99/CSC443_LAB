
function toggleColors() {
    $("td").toggleClass("colored");

}

function toggleBorders() {
    if($("td").attr("style")===undefined) {
        $("td").attr("style", "background-color: salmon;");}
    else {
        $("td").removeAttr("style");}
   // $("td").toggleAttribute("style") should also be possible.
}

function addBox() {
    $("td:last").after("<tr><td></td></tr>");
}