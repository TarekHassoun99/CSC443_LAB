var canvas = document.querySelector('canvas');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

var c = canvas.getContext('2d');

function clearCanvas() {
    c.clearRect(0,0, canvas.width, canvas.height);
}
function drawTriangle() {
//Straight triangle
//The line draw
c.beginPath();
c.moveTo(50, 300); 
c.lineTo(100, 300);
c.lineTo(75, 250);
c.lineTo(50, 300);
c.closePath

//The outline
c.strokeStyle = "blue"; 
c.lineWidth = 2;
c.stroke();

//Coloring

c.fillStyle = "red";
c.fill();
}

function drawRotatedTriangle() {
//Rotated triangle.
//The line draw
c.beginPath();
c.fillStyle = "red";
c.moveTo(300, 500); 
c.lineTo(400, 400);
c.lineTo(300, 400);
c.lineTo(300, 500);
c.closePath

//The outline
c.strokeStyle = "blue"; 
c.lineWidth = 2;
c.stroke();

//Coloring

c.fillStyle = "red";
c.fill();
}
